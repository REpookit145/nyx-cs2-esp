#include "hooks.hpp"
#include "log.hpp"
#include "offsets.hpp"

#include <windows.h>
#include <intrin.h>
#include <string>

namespace {

HMODULE g_self = nullptr;

// ---- minimal PEB types (no winternl.h dependency) ----------------------
struct list_entry_t {
    list_entry_t* flink;
    list_entry_t* blink;
};

struct peb_ldr_t {
    unsigned long length;
    unsigned long initialized;
    void*         ss_handle;
    list_entry_t  in_load;   // 0x10
    list_entry_t  in_mem;    // 0x20
    list_entry_t  in_init;   // 0x30
};

struct ldr_entry_t {
    list_entry_t  in_load;       // 0x00
    list_entry_t  in_mem;        // 0x10
    list_entry_t  in_init;       // 0x20
    void*         dll_base;      // 0x30
    void*         entry_point;   // 0x38
    unsigned long size_of_image; // 0x40
};

struct peb_t {
    unsigned char pad[0x18];
    void*         ldr;           // PEB.Ldr at +0x18
};

// Unlink this module from the three loader lists. The image stays mapped and
// fully callable; it just stops appearing in EnumProcessModules-style walks.
void unlink_from_loader(HMODULE mod) {
    __try {
        auto* peb = reinterpret_cast<peb_t*>(__readgsqword(0x60));
        if (!peb || !peb->ldr) return;

        auto* ldr = reinterpret_cast<peb_ldr_t*>(peb->ldr);
        auto* head = &ldr->in_load;

        for (auto* cur = head->flink; cur != head; cur = cur->flink) {
            auto* e = reinterpret_cast<ldr_entry_t*>(cur);
            if (e->dll_base != mod) continue;

            e->in_load.flink->blink = e->in_load.blink;
            e->in_load.blink->flink = e->in_load.flink;
            e->in_mem.flink->blink = e->in_mem.blink;
            e->in_mem.blink->flink = e->in_mem.flink;
            e->in_init.flink->blink = e->in_init.blink;
            e->in_init.blink->flink = e->in_init.flink;
            return;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
}

std::wstring module_dir(HMODULE mod) {
    wchar_t path[MAX_PATH]{};
    GetModuleFileNameW(mod, path, MAX_PATH);
    std::wstring s{ path };
    const auto pos = s.find_last_of(L"\\/");
    return pos == std::wstring::npos ? s : s.substr(0, pos);
}

std::string to_narrow(const std::wstring& w) {
    if (w.empty()) return {};
    const int len = WideCharToMultiByte(CP_UTF8, 0, w.c_str(),
                                        static_cast<int>(w.size()),
                                        nullptr, 0, nullptr, nullptr);
    std::string s(static_cast<std::size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), static_cast<int>(w.size()),
                        s.data(), len, nullptr, nullptr);
    return s;
}

DWORD WINAPI bootstrap(LPVOID) {
    nyx::logf("[DllMain] bootstrap thread awake");
    Sleep(250); // let the game finish any in-flight present
    hooks::install();
    return 0;
}

} // namespace

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    switch (reason) {
    case DLL_PROCESS_ATTACH:
        g_self = module;
        DisableThreadLibraryCalls(module);
        nyx::logf("[DllMain] PROCESS_ATTACH module=%p", (void*)module);
        {
            const auto dir = module_dir(module);
            load_offsets(to_narrow(dir) + "\\offsets.ini");
            nyx::logf("[DllMain] offsets loaded; client.dll=%p",
                      (void*)GetModuleHandleA("client.dll"));
        }
        {
            HANDLE th = CreateThread(nullptr, 0, bootstrap, nullptr, 0, nullptr);
            nyx::logf("[DllMain] CreateThread=%p", (void*)th);
        }
        unlink_from_loader(module);
        nyx::logf("[DllMain] unlinked from loader list");
        break;

    case DLL_PROCESS_DETACH:
        // ImGui/D3D cleanup is intentionally skipped on forced unload; the
        // Present hook lives until process exit.
        break;
    }
    return TRUE;
}
