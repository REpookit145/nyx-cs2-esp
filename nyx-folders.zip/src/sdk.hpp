#pragma once
// Minimal Source 2 / CS2 SDK types. Only what the ESP needs.

#include <cstdint>
#include <cmath>

namespace sdk {

struct Vector3 {
    float x, y, z;

    Vector3 operator+(const Vector3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vector3 operator-(const Vector3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    Vector3 operator*(float s) const { return { x * s, y * s, z * s }; }
    float dot(const Vector3& o) const { return x * o.x + y * o.y + z * o.z; }
    float length_sqr() const { return dot(*this); }
    float length() const { return std::sqrt(length_sqr()); }
};

struct Vector2 {
    float x, y;
};

// 4x4 view matrix, row-major as stored by Source 2.
struct ViewMatrix {
    float m[4][4];
};

// A bone transform is 0x20 bytes; the world position sits at +0x10.
struct Bone {
    float pad0[4];   // rotation / unused
    Vector3 origin;  // +0x10
    float pad1;
};

struct Color {
    float r, g, b, a;
};

} // namespace sdk
