#pragma once
// 4x4 toggle grid menu drawn with ImGui.

namespace menu {

void render();

} // namespace menu
