#pragma once
// ESP overlay logic: entity scan + world-to-screen + draw.
// Drawn onto the ImGui background draw list each frame.

#include "sdk.hpp"

#include <cstdint>

struct ImDrawList;

namespace esp {

// Live state from the last rendered frame. The menu reads this to prove the
// memory chain is actually resolving (not just an idle overlay).
struct stats_t {
    bool  client_ok = false;
    bool  view_ok   = false;
    bool  local_ok  = false;
    int   local_team   = 0;
    int   local_health = 0;
    int   scanned   = 0;   // pawns found
    int   drawn     = 0;   // boxes actually drawn
    int   bones     = 0;   // players with sane skeleton data
    float matrix_w  = 0.0f;
};

extern stats_t g_stats;

bool world_to_screen(const sdk::Vector3& world, sdk::Vector2& out,
                     const sdk::ViewMatrix& vm, int width, int height);

// Draws all ESP elements for the current frame.
void render(ImDrawList* draw, int width, int height);

} // namespace esp
