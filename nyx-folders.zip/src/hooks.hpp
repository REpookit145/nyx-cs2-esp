#pragma once

namespace hooks {

// Installs the DXGI Present hook. Safe to call once from a worker thread.
void install();

} // namespace hooks
