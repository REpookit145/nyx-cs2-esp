#include "esp.hpp"

#include "config.hpp"
#include "log.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <imgui.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

using namespace sdk;

namespace esp { stats_t g_stats; }

namespace {

// Bone indices for the CS2 skeleton (position at +0x00 of each 0x20-byte bone).
enum bone_id : int {
    BONE_PELVIS      = 0,
    BONE_SPINE_2     = 2,
    BONE_SPINE_1     = 4,
    BONE_NECK        = 5,
    BONE_HEAD        = 6,
    BONE_SHOULDER_L  = 8,
    BONE_ELBOW_L     = 9,
    BONE_HAND_L      = 10,
    BONE_SHOULDER_R  = 13,
    BONE_ELBOW_R     = 14,
    BONE_HAND_R      = 15,
    BONE_HIP_L       = 22,
    BONE_KNEE_L      = 23,
    BONE_FOOT_L      = 24,
    BONE_HIP_R       = 25,
    BONE_KNEE_R      = 26,
    BONE_FOOT_R      = 27,
};

constexpr int k_max_bone = 128;
constexpr float k_eye_height = 72.0f; // Source units above feet, ~1.83 m

// One throttled diagnostic line per second so the log pinpoints where the
// entity chain breaks instead of silently drawing nothing.
ULONGLONG g_last_diag = 0;
bool diag_due() {
    const ULONGLONG now = GetTickCount64();
    if (now - g_last_diag < 1000) return false;
    g_last_diag = now;
    return true;
}

// A real bone sits within a sane radius of the entity origin; the quaternion
// fields (if we ever read the wrong offset) land almost exactly on it.
bool bone_sane(const Vector3& bone, const Vector3& origin) {
    const float d2 = (bone - origin).length_sqr();
    return d2 > 1.0f && d2 < 150.0f * 150.0f;
}

// One-shot dump of the view matrix and the entity chain so a broken offset
// shows up immediately in the log instead of as a blank screen.
void probe_once(std::uintptr_t client, std::uintptr_t local_ctrl,
                const ViewMatrix& view) {
    static bool done = false;
    if (done) return;
    done = true;

    for (int r = 0; r < 4; ++r)
        nyx::logf("[probe] vm[%d] = %.4f %.4f %.4f %.4f", r,
                  view.m[r][0], view.m[r][1], view.m[r][2], view.m[r][3]);

    const auto sys = mem::read<std::uintptr_t>(client + g_offsets.entity_list);
    const std::uint32_t handle =
        mem::read<std::uint32_t>(local_ctrl + g_offsets.m_hPlayerPawn);
    const int idx = static_cast<int>(handle & 0x7FFF);

    nyx::logf("[probe] sys=%p handle=0x%X idx=%d stride=0x%llX", (void*)sys,
              handle, idx,
              (unsigned long long)g_offsets.entity_list_entry_stride);

    const auto chunk = mem::read<std::uintptr_t>(
        sys + g_offsets.entity_list_chunk_base +
        g_offsets.entity_list_chunk_stride * (idx >> 9));

    // Try the known identity strides so a wrong one is obvious in the log.
    const std::uintptr_t strides[] = { 0x70, 0x78, 0x68, 0x80 };
    for (auto stride : strides) {
        const auto ent = mem::read<std::uintptr_t>(
            chunk + stride * (idx & 0x1FF));
        nyx::logf("[probe] chunk=%p stride=0x%llX ent=%p hp=%d team=%d scene=%p",
                  (void*)chunk, (unsigned long long)stride, (void*)ent,
                  mem::read<int>(ent + g_offsets.m_iHealth),
                  mem::read<int>(ent + g_offsets.m_iTeamNum),
                  (void*)mem::read<std::uintptr_t>(ent + g_offsets.m_pGameSceneNode));
    }

    for (int i = 1; i <= 5; ++i) {
        const auto c = mem::read<std::uintptr_t>(
            chunk + g_offsets.entity_list_entry_stride * (i & 0x1FF));
        nyx::logf("[probe] ctrl[%d]=%p hp=%d team=%d hpawn=0x%X", i, (void*)c,
                  mem::read<int>(c + g_offsets.m_iHealth),
                  mem::read<int>(c + g_offsets.m_iTeamNum),
                  mem::read<std::uint32_t>(c + g_offsets.m_hPlayerPawn));
    }
}

struct player_info {
    std::uintptr_t pawn = 0;
    int team = 0;
    int health = 0;
    Vector3 origin{};
    Vector3 head{};
    Vector3 bones[k_max_bone]{};
    bool has_bones = false;
    int index = 0;
};

std::uintptr_t get_entity(std::uintptr_t client, int index) {
    const auto list = mem::read<std::uintptr_t>(client + g_offsets.entity_list);
    if (!list) return 0;

    const auto chunk = mem::read<std::uintptr_t>(
        list + g_offsets.entity_list_chunk_base +
        g_offsets.entity_list_chunk_stride * (index >> 9));
    if (!chunk) return 0;

    return mem::read<std::uintptr_t>(
        chunk + g_offsets.entity_list_entry_stride * (index & 0x1FF));
}

std::uintptr_t get_entity_from_handle(std::uintptr_t client, std::uint32_t handle) {
    if (!handle || handle == 0xFFFFFFFF) return 0;
    const auto list = mem::read<std::uintptr_t>(client + g_offsets.entity_list);
    if (!list) return 0;

    const int idx = static_cast<int>(handle & 0x7FFF);
    const int chunk_idx = idx >> 9;

    const auto chunk = mem::read<std::uintptr_t>(
        list + g_offsets.entity_list_chunk_base +
        g_offsets.entity_list_chunk_stride * chunk_idx);
    if (!chunk) return 0;

    return mem::read<std::uintptr_t>(
        chunk + g_offsets.entity_list_entry_stride * (idx & 0x1FF));
}

bool read_bones(std::uintptr_t scene, Vector3 (&out)[k_max_bone]) {
    const auto model_state = scene + g_offsets.m_modelState;
    const auto array = mem::read<std::uintptr_t>(model_state + g_offsets.bone_array_offset);
    if (!array) return false;

    for (int i = 0; i < k_max_bone; ++i) {
        // Each CTransform is 0x20 bytes: quaternion at +0x00, world position
        // at +0x10. Reading +0x00 gave us the quaternion and killed the ESP.
        out[i] = mem::read<Vector3>(array + g_offsets.bone_stride * i +
                                    g_offsets.bone_pos_offset);
    }
    return true;
}

ImU32 team_color(int team, int alpha = 255) {
    // 2 = T (orange), 3 = CT (blue)
    if (team == 2) return IM_COL32(245, 160, 40, alpha);
    if (team == 3) return IM_COL32(70, 160, 245, alpha);
    return IM_COL32(220, 220, 220, alpha);
}

void draw_box(ImDrawList* d, float x, float y, float w, float h, ImU32 col, float thick) {
    if (g_cfg.fill_box)
        d->AddRectFilled({ x, y }, { x + w, y + h }, IM_COL32(0, 0, 0, 45));

    if (g_cfg.corner_box) {
        const float cx = w * 0.25f;
        const float cy = h * 0.25f;
        const float t = thick * 2.0f;
        // corners
        d->AddLine({ x, y }, { x + cx, y }, col, t);
        d->AddLine({ x, y }, { x, y + cy }, col, t);
        d->AddLine({ x + w, y }, { x + w - cx, y }, col, t);
        d->AddLine({ x + w, y }, { x + w, y + cy }, col, t);
        d->AddLine({ x, y + h }, { x + cx, y + h }, col, t);
        d->AddLine({ x, y + h }, { x, y + h - cy }, col, t);
        d->AddLine({ x + w, y + h }, { x + w - cx, y + h }, col, t);
        d->AddLine({ x + w, y + h }, { x + w, y + h - cy }, col, t);
    } else {
        d->AddRect({ x, y }, { x + w, y + h }, col, 0.0f, 0, thick);
    }
}

void draw_health(ImDrawList* d, float x, float y, float h, int health) {
    const float frac = std::clamp(health / 100.0f, 0.0f, 1.0f);
    const float bx = x - 5.0f;
    // background
    d->AddRectFilled({ bx, y - 1 }, { bx + 3, y + h + 1 }, IM_COL32(0, 0, 0, 160));
    // fill: green at full, yellow mid, red low
    const ImU32 col = IM_COL32(
        static_cast<int>(255 * (1.0f - frac)),
        static_cast<int>(255 * frac),
        40, 230);
    const float fh = h * frac;
    d->AddRectFilled({ bx, y + (h - fh) }, { bx + 3, y + h }, col);
}

void draw_skeleton(ImDrawList* d, const player_info& p, const ViewMatrix& vm,
                   int sw, int sh, ImU32 col, float thick) {
    if (!p.has_bones) return;

    struct link { int a, b; };
    static const link links[] = {
        // spine
        { BONE_PELVIS,     BONE_SPINE_2 },
        { BONE_SPINE_2,    BONE_SPINE_1 },
        { BONE_SPINE_1,    BONE_NECK },
        { BONE_NECK,       BONE_HEAD },
        // left arm
        { BONE_NECK,       BONE_SHOULDER_L },
        { BONE_SHOULDER_L, BONE_ELBOW_L },
        { BONE_ELBOW_L,    BONE_HAND_L },
        // right arm
        { BONE_NECK,       BONE_SHOULDER_R },
        { BONE_SHOULDER_R, BONE_ELBOW_R },
        { BONE_ELBOW_R,    BONE_HAND_R },
        // left leg
        { BONE_PELVIS,     BONE_HIP_L },
        { BONE_HIP_L,      BONE_KNEE_L },
        { BONE_KNEE_L,     BONE_FOOT_L },
        // right leg
        { BONE_PELVIS,     BONE_HIP_R },
        { BONE_HIP_R,      BONE_KNEE_R },
        { BONE_KNEE_R,     BONE_FOOT_R },
    };

    for (const auto& l : links) {
        Vector2 a, b;
        if (!esp::world_to_screen(p.bones[l.a], a, vm, sw, sh)) continue;
        if (!esp::world_to_screen(p.bones[l.b], b, vm, sw, sh)) continue;
        d->AddLine({ a.x, a.y }, { b.x, b.y }, col, thick);
    }
}

} // namespace

namespace esp {

bool world_to_screen(const Vector3& world, Vector2& out, const ViewMatrix& vm,
                     int width, int height) {
    const float w = vm.m[3][0] * world.x + vm.m[3][1] * world.y +
                    vm.m[3][2] * world.z + vm.m[3][3];
    if (w < 0.001f) return false;

    const float inv = 1.0f / w;
    const float nx = (vm.m[0][0] * world.x + vm.m[0][1] * world.y +
                      vm.m[0][2] * world.z + vm.m[0][3]) * inv;
    const float ny = (vm.m[1][0] * world.x + vm.m[1][1] * world.y +
                      vm.m[1][2] * world.z + vm.m[1][3]) * inv;

    out.x = (width * 0.5f) + (nx * width * 0.5f);
    out.y = (height * 0.5f) - (ny * height * 0.5f);
    return true;
}

void render(ImDrawList* draw, int width, int height) {
    g_stats = stats_t{};
    if (!g_cfg.enabled || !draw) return;

    const auto client = mem::module_base("client.dll");
    if (!client) {
        if (diag_due()) nyx::logf("[diag] client.dll not loaded");
        return;
    }
    g_stats.client_ok = true;

    const auto view = mem::read<ViewMatrix>(client + g_offsets.view_matrix);
    g_stats.matrix_w = view.m[3][3];
    if (view.m[3][3] == 0.0f) {
        if (diag_due())
            nyx::logf("[diag] view matrix zero -> dwViewMatrix wrong (client=%p)",
                      (void*)client);
        return;
    }
    g_stats.view_ok = true;

    const auto local_ctrl = mem::read<std::uintptr_t>(client + g_offsets.local_player_controller);
    if (!local_ctrl) {
        if (diag_due())
            nyx::logf("[diag] local_player_controller null -> offset wrong or not in a match");
        return;
    }

    const auto local_pawn = get_entity_from_handle(
        client, mem::read<std::uint32_t>(local_ctrl + g_offsets.m_hPlayerPawn));
    const int local_team = local_pawn ? mem::read<int>(local_pawn + g_offsets.m_iTeamNum) : 0;

    g_stats.local_ok = local_pawn != 0;
    g_stats.local_team = local_team;
    if (local_pawn)
        g_stats.local_health = mem::read<int>(local_pawn + g_offsets.m_iHealth);

    probe_once(client, local_ctrl, view);

    Vector3 my_pos{};
    if (local_pawn) {
        const auto my_scene = mem::read<std::uintptr_t>(local_pawn + g_offsets.m_pGameSceneNode);
        if (my_scene) my_pos = mem::read<Vector3>(my_scene + g_offsets.m_vecAbsOrigin);
    }

    const float thick = g_cfg.box_thickness;
    int scanned = 0, passed = 0, bones_ok = 0, drawn = 0;

    for (int i = 1; i <= g_offsets.max_players; ++i) {
        const auto ctrl = get_entity(client, i);
        if (!ctrl || ctrl == local_ctrl) continue;

        const auto pawn = get_entity_from_handle(
            client, mem::read<std::uint32_t>(ctrl + g_offsets.m_hPlayerPawn));
        if (!pawn) continue;
        ++scanned;

        const auto scene = mem::read<std::uintptr_t>(pawn + g_offsets.m_pGameSceneNode);
        if (!scene) continue;

        if (g_cfg.dormant_check && mem::read<std::uint8_t>(scene + g_offsets.m_bDormant))
            continue;

        const int team = mem::read<int>(pawn + g_offsets.m_iTeamNum);
        if (g_cfg.team_check && team == local_team) continue;

        const int health = mem::read<int>(pawn + g_offsets.m_iHealth);
        if (health <= 0 || health > 100) continue;

        const auto life = mem::read<std::uint8_t>(pawn + g_offsets.m_lifeState);
        if (life != 0) continue; // LIFE_ALIVE == 0

        player_info p{};
        p.pawn = pawn;
        p.team = team;
        p.health = health;
        p.index = i;
        p.origin = mem::read<Vector3>(scene + g_offsets.m_vecAbsOrigin);

        if (local_pawn && g_cfg.max_distance > 0.0f &&
            (p.origin - my_pos).length_sqr() >
                g_cfg.max_distance * g_cfg.max_distance)
            continue;

        p.has_bones = read_bones(scene, p.bones);

        // Fallback head: eye height above the feet. Keeps the box drawing even
        // if the bone array is missing or the bone offset is stale.
        p.head = p.origin + Vector3{ 0.0f, 0.0f, k_eye_height };
        if (p.has_bones && bone_sane(p.bones[BONE_HEAD], p.origin)) {
            p.head = p.bones[BONE_HEAD];
            ++bones_ok;
        } else {
            p.has_bones = false; // don't draw a garbage skeleton
        }

        ++passed;

        Vector2 top, bottom;
        if (!world_to_screen(p.head, top, view, width, height)) continue;
        if (!world_to_screen(p.origin, bottom, view, width, height)) continue;

        float bh = bottom.y - top.y;
        if (bh < 4.0f || bh > height * 1.5f) continue;
        float bw = bh * 0.45f;
        float bx = (top.x + bottom.x) * 0.5f - bw * 0.5f;
        float by = top.y;

        const ImU32 col = team_color(team);
        ++drawn;

        if (g_cfg.snapline) {
            draw->AddLine({ width * 0.5f, static_cast<float>(height) },
                          { top.x, bottom.y }, col, thick);
        }

        if (g_cfg.box) draw_box(draw, bx, by, bw, bh, col, thick);
        if (g_cfg.health_bar) draw_health(draw, bx, by, bh, health);
        if (g_cfg.skeleton) draw_skeleton(draw, p, view, width, height, col, thick);
        if (g_cfg.head_dot) draw->AddCircleFilled({ top.x, top.y }, 3.0f, col);

        char line[64];
        if (g_cfg.distance) {
            const float meters = (p.origin - my_pos).length() * 0.0254f;
            std::snprintf(line, sizeof(line), "%d m", static_cast<int>(meters));
            draw->AddText({ bx + bw * 0.5f - 10.0f, by + bh + 2.0f },
                          IM_COL32(220, 220, 220, 220), line);
        }
        if (g_cfg.name) {
            std::snprintf(line, sizeof(line), "p%d [%d]", i, health);
            draw->AddText({ bx, by - 14.0f }, col, line);
        }
    }

    g_stats.scanned = scanned;
    g_stats.drawn = drawn;
    g_stats.bones = bones_ok;

    if (diag_due())
        nyx::logf("[diag] ctrl=%p team=%d scanned=%d passed=%d drawn=%d bones=%d vm33=%.3f",
                  (void*)local_ctrl, local_team, scanned, passed, drawn, bones_ok,
                  view.m[3][3]);
}

} // namespace esp
