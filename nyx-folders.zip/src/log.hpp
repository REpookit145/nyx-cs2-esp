#pragma once
// Fixed-path logger so the log is always in the same place regardless of the
// host process's TEMP.
#include <cstdio>
#include <cstdarg>

namespace nyx {

inline const char* log_path() {
    return R"(C:\Users\sebastian\Documents\Default Project\cs2-esp\cs2_esp.log)";
}

inline void logf(const char* fmt, ...) {
    FILE* f = nullptr;
    fopen_s(&f, log_path(), "a");
    if (!f) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

inline void log_reset() {
    FILE* f = nullptr;
    fopen_s(&f, log_path(), "w");
    if (f) fclose(f);
}

} // namespace nyx
