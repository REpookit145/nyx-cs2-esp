#pragma once
// Offsets are version dependent. They are loaded at runtime from offsets.ini
// (next to the DLL) so you can update them after a CS2 patch without rebuilding.
// If a key is missing from the ini, the built-in default below is used.

#include <cstdint>
#include <string>

struct game_offsets {
    // client.dll offsets
    std::uintptr_t local_player_controller = 0x0;
    std::uintptr_t entity_list            = 0x0;
    std::uintptr_t view_matrix            = 0x0;
    std::uintptr_t global_vars            = 0x0;

    // netvars (schema offsets, relative to entity)
    std::uintptr_t m_iTeamNum             = 0x0;
    std::uintptr_t m_iHealth              = 0x0;
    std::uintptr_t m_lifeState            = 0x0;
    std::uintptr_t m_hPlayerPawn          = 0x0;
    std::uintptr_t m_pGameSceneNode       = 0x0;
    std::uintptr_t m_modelState           = 0x0;
    std::uintptr_t m_vecAbsOrigin         = 0x0;
    std::uintptr_t m_bDormant             = 0x0;
    std::uintptr_t m_szWeaponName         = 0x0;

    // entity list walking geometry (these are stable-ish structure constants)
    std::uintptr_t entity_list_chunk_base = 0x10;
    std::uintptr_t entity_list_chunk_stride = 0x8;
    std::uintptr_t entity_list_entry_stride = 0x70; // sizeof(CEntityIdentity) on current builds
    std::uintptr_t bone_array_offset      = 0x80;
    std::uintptr_t bone_stride            = 0x20;
    std::uintptr_t bone_pos_offset        = 0x10; // CTransform: quat at +0x00, pos at +0x10

    // max players to scan
    int max_players = 64;
};

extern game_offsets g_offsets;

// Load offsets.ini from the given directory. Returns number of keys overridden.
int load_offsets(const std::string& ini_path);
