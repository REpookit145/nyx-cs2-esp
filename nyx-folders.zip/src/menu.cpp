#include "menu.hpp"

#include "config.hpp"
#include "esp.hpp"
#include "memory.hpp"
#include "offsets.hpp"

#include <imgui.h>

#include <cstdio>

namespace menu {

namespace {

struct feature {
    const char* label;
    bool*       value;
};

feature g_features[] = {
    { "ESP",        &g_cfg.enabled },
    { "Box",        &g_cfg.box },
    { "Corner",     &g_cfg.corner_box },
    { "Fill",       &g_cfg.fill_box },
    { "Skeleton",   &g_cfg.skeleton },
    { "Health",     &g_cfg.health_bar },
    { "Head Dot",   &g_cfg.head_dot },
    { "Snapline",   &g_cfg.snapline },
    { "Distance",   &g_cfg.distance },
    { "Name",       &g_cfg.name },
    { "Team Check", &g_cfg.team_check },
    { "Dormant",    &g_cfg.dormant_check },
};

void apply_style() {
    static bool done = false;
    if (done) return;
    done = true;

    auto& s = ImGui::GetStyle();
    s.WindowRounding  = 8.0f;
    s.ChildRounding   = 6.0f;
    s.FrameRounding   = 5.0f;
    s.GrabRounding    = 4.0f;
    s.WindowPadding   = ImVec2(14, 14);
    s.FramePadding    = ImVec2(8, 5);
    s.ItemSpacing     = ImVec2(6, 6);

    ImVec4* c = s.Colors;
    c[ImGuiCol_WindowBg]        = ImVec4(0.06f, 0.07f, 0.08f, 0.98f);
    c[ImGuiCol_ChildBg]         = ImVec4(0.09f, 0.10f, 0.11f, 1.00f);
    c[ImGuiCol_Border]          = ImVec4(0.18f, 0.20f, 0.22f, 1.00f);
    c[ImGuiCol_FrameBg]         = ImVec4(0.13f, 0.14f, 0.16f, 1.00f);
    c[ImGuiCol_FrameBgHovered]  = ImVec4(0.17f, 0.19f, 0.21f, 1.00f);
    c[ImGuiCol_SliderGrab]      = ImVec4(0.20f, 0.75f, 0.45f, 1.00f);
    c[ImGuiCol_SliderGrabActive]= ImVec4(0.25f, 0.85f, 0.52f, 1.00f);
    c[ImGuiCol_Text]            = ImVec4(0.88f, 0.90f, 0.92f, 1.00f);
    c[ImGuiCol_TextDisabled]    = ImVec4(0.50f, 0.53f, 0.56f, 1.00f);
}

bool toggle_button(const char* label, bool active, const ImVec2& size) {
    ImGui::PushStyleColor(ImGuiCol_Button,
        active ? ImVec4(0.13f, 0.48f, 0.30f, 1.0f)
               : ImVec4(0.15f, 0.16f, 0.18f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered,
        active ? ImVec4(0.17f, 0.58f, 0.37f, 1.0f)
               : ImVec4(0.22f, 0.24f, 0.27f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive,
        ImVec4(0.10f, 0.40f, 0.25f, 1.0f));
    if (active)
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 1.0f, 0.85f, 1.0f));

    const bool clicked = ImGui::Button(label, size);
    ImGui::PopStyleColor(active ? 4 : 3);
    return clicked;
}

void dot(bool ok) {
    ImGui::TextColored(ok ? ImVec4(0.30f, 0.90f, 0.50f, 1.0f)
                          : ImVec4(0.90f, 0.35f, 0.35f, 1.0f), "o");
    ImGui::SameLine();
}

void status(const char* label, const char* value, bool ok) {
    dot(ok);
    ImGui::TextDisabled("%s", label);
    ImGui::SameLine(132.0f);
    ImGui::TextUnformatted(value);
}

} // namespace

void render() {
    if (!g_menu_open) return;
    apply_style();

    ImGui::SetNextWindowSize({ 620, 470 }, ImGuiCond_FirstUseEver);
    ImGui::Begin("nyx // cs2 esp", nullptr,
                 ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);

    ImGui::TextColored(ImVec4(0.30f, 0.90f, 0.50f, 1.0f), "NYX");
    ImGui::SameLine();
    ImGui::TextDisabled("// counter-strike 2");
    ImGui::Separator();

    constexpr float left_w = 330.0f;
    ImGui::BeginChild("##features", ImVec2(left_w, 0), true);
    ImGui::TextDisabled("FEATURES");
    ImGui::Spacing();

    const ImVec2 cell((left_w - 28.0f - 12.0f) / 3.0f, 34.0f);
    int i = 0;
    for (auto& f : g_features) {
        if ((i % 3) != 0) ImGui::SameLine();
        if (toggle_button(f.label, *f.value, cell)) *f.value = !*f.value;
        ++i;
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextDisabled("ACTIONS");
    ImGui::Spacing();

    const ImVec2 act((left_w - 28.0f - 12.0f) / 3.0f, 32.0f);
    if (toggle_button("Thick+", false, act))
        g_cfg.box_thickness =
            (g_cfg.box_thickness >= 4.0f) ? 1.0f : g_cfg.box_thickness + 1.0f;
    ImGui::SameLine();
    if (toggle_button("Reset", false, act)) g_cfg = esp_config{};
    ImGui::SameLine();
    if (toggle_button("Hide", false, act)) g_menu_open = false;

    ImGui::EndChild();

    ImGui::SameLine();

    ImGui::BeginChild("##status", ImVec2(0, 0), true);
    ImGui::TextDisabled("STATUS");
    ImGui::Spacing();

    char buf[64];
    const auto client = mem::module_base("client.dll");
    std::snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)client);
    status("client.dll", client ? buf : "not found", client != 0);

    const auto& st = esp::g_stats;
    status("view matrix", st.view_ok ? "ok" : "waiting", st.view_ok);
    status("local player", st.local_ok ? "resolved" : "none", st.local_ok);

    std::snprintf(buf, sizeof(buf), "%d / %d", st.drawn, st.scanned);
    status("drawn / scanned", buf, st.drawn > 0);

    std::snprintf(buf, sizeof(buf), "%d", st.bones);
    status("skeletons", buf, st.bones > 0);

    if (st.local_ok) {
        const char* team =
            st.local_team == 2 ? "T" : st.local_team == 3 ? "CT" : "?";
        std::snprintf(buf, sizeof(buf), "%s  %d hp", team, st.local_health);
        status("you", buf, true);
    }

    std::snprintf(buf, sizeof(buf), "%.0f", ImGui::GetIO().Framerate);
    status("fps", buf, true);

    std::snprintf(buf, sizeof(buf), "%d", ImGui::GetFrameCount());
    status("frames", buf, true);

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextDisabled("TUNING");
    ImGui::Spacing();

    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##thick", &g_cfg.box_thickness, 1.0f, 4.0f,
                       "thickness %.1f");
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##dist", &g_cfg.max_distance, 500.0f, 8000.0f,
                       "max dist %.0f");

    ImGui::EndChild();

    ImGui::Separator();
    ImGui::TextDisabled("INSERT toggles the menu");

    ImGui::End();
}

} // namespace menu
