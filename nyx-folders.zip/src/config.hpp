#pragma once
// Runtime feature toggles. The 4x4 menu flips these booleans.

struct esp_config {
    bool enabled        = true;   // master switch

    // drawing options (each maps to a cell in the 4x4 grid)
    bool box            = true;
    bool corner_box     = false;
    bool fill_box       = false;
    bool skeleton       = true;
    bool health_bar     = true;
    bool name           = false;
    bool distance       = false;
    bool head_dot       = true;
    bool snapline       = false;
    bool team_check     = true;
    bool visible_only   = false;
    bool dormant_check  = true;

    // spacing / colors
    float max_distance  = 4000.0f;
    float box_thickness = 1.5f;
};

inline esp_config g_cfg;
inline bool g_menu_open = true;   // menu opens automatically on inject
