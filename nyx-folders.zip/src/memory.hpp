#pragma once
// Thin, checked memory helpers. Everything reads from the host process
// (we are injected in-process, so "reads" are just dereferences with null guards).

#include <cstdint>
#include <windows.h>

namespace mem {

template <typename T>
inline T read(std::uintptr_t address) {
    if (!address) return T{};
    __try {
        return *reinterpret_cast<T*>(address);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return T{};
    }
}

inline bool valid(std::uintptr_t address) {
    if (!address || address < 0x10000) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<LPCVOID>(address), &mbi, sizeof(mbi)))
        return false;
    return mbi.State == MEM_COMMIT &&
           !(mbi.Protect & PAGE_NOACCESS) &&
           !(mbi.Protect & PAGE_GUARD);
}

inline std::uintptr_t module_base(const char* name) {
    return reinterpret_cast<std::uintptr_t>(GetModuleHandleA(name));
}

} // namespace mem
