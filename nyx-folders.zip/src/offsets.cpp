#include "offsets.hpp"

#include <fstream>
#include <sstream>
#include <unordered_map>
#include <cstdlib>

game_offsets g_offsets;

namespace {

std::unordered_map<std::string, std::uintptr_t*> numeric_bindings() {
    return {
        { "dwLocalPlayerController", &g_offsets.local_player_controller },
        { "dwEntityList",            &g_offsets.entity_list },
        { "dwViewMatrix",            &g_offsets.view_matrix },
        { "dwGlobalVars",            &g_offsets.global_vars },

        { "m_iTeamNum",              &g_offsets.m_iTeamNum },
        { "m_iHealth",               &g_offsets.m_iHealth },
        { "m_lifeState",             &g_offsets.m_lifeState },
        { "m_hPlayerPawn",           &g_offsets.m_hPlayerPawn },
        { "m_pGameSceneNode",        &g_offsets.m_pGameSceneNode },
        { "m_modelState",            &g_offsets.m_modelState },
        { "m_vecAbsOrigin",          &g_offsets.m_vecAbsOrigin },
        { "m_bDormant",              &g_offsets.m_bDormant },
        { "m_szWeaponName",          &g_offsets.m_szWeaponName },

        { "entity_list_chunk_base",   &g_offsets.entity_list_chunk_base },
        { "entity_list_chunk_stride", &g_offsets.entity_list_chunk_stride },
        { "entity_list_entry_stride", &g_offsets.entity_list_entry_stride },
        { "bone_array_offset",        &g_offsets.bone_array_offset },
        { "bone_stride",              &g_offsets.bone_stride },
        { "bone_pos_offset",          &g_offsets.bone_pos_offset },
    };
}

std::string trim(std::string s) {
    const char* ws = " \t\r\n";
    const auto first = s.find_first_not_of(ws);
    if (first == std::string::npos) return {};
    const auto last = s.find_last_not_of(ws);
    return s.substr(first, last - first + 1);
}

} // namespace

int load_offsets(const std::string& ini_path) {
    std::ifstream f(ini_path);
    if (!f.is_open()) return 0;

    auto bindings = numeric_bindings();
    int applied = 0;
    std::string line;

    while (std::getline(f, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#' || line[0] == ';' || line[0] == '[')
            continue;

        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;

        const std::string key = trim(line.substr(0, eq));
        std::string val = trim(line.substr(eq + 1));

        // strip inline comment
        const auto hash = val.find_first_of("#;");
        if (hash != std::string::npos) val = trim(val.substr(0, hash));
        if (val.empty()) continue;

        if (key == "max_players") {
            g_offsets.max_players = std::atoi(val.c_str());
            ++applied;
            continue;
        }

        auto it = bindings.find(key);
        if (it == bindings.end()) continue;

        *it->second = static_cast<std::uintptr_t>(std::strtoull(val.c_str(), nullptr, 0));
        ++applied;
    }
    return applied;
}
