#include "hooks.hpp"

#include "config.hpp"
#include "esp.hpp"
#include "log.hpp"
#include "menu.hpp"

#include <imgui.h>
#include <imgui_impl_dx11.h>
#include <imgui_impl_win32.h>

#include <d3d11.h>
#include <dxgi.h>
#include <dxgi1_2.h>

#include <cstdint>
#include <cstdarg>
#include <cstdio>
#include <cwchar>
#include <string>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

// The header hides this behind #if 0; declare it here (as instructed).
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg,
                                                             WPARAM wParam, LPARAM lParam);

namespace {

using present_fn  = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);
using present1_fn = HRESULT(__stdcall*)(IDXGISwapChain1*, UINT, UINT,
                                        const DXGI_PRESENT_PARAMETERS*);

present_fn  o_present  = nullptr;
present1_fn o_present1 = nullptr;
WNDPROC     o_wndproc  = nullptr;

ID3D11Device*           g_device  = nullptr;
ID3D11DeviceContext*    g_context = nullptr;
ID3D11RenderTargetView* g_rtv     = nullptr;
HWND                    g_hwnd    = nullptr;
bool                    g_running = false;

// ---- file logger (fixed path so it's always findable) -----------------
using nyx::logf;
void log_init() { nyx::log_reset(); }

void create_render_target(IDXGISwapChain* swap) {
    ID3D11Texture2D* backbuffer = nullptr;
    if (SUCCEEDED(swap->GetBuffer(0, __uuidof(ID3D11Texture2D),
                                  reinterpret_cast<void**>(&backbuffer))) && backbuffer) {
        g_device->CreateRenderTargetView(backbuffer, nullptr, &g_rtv);
        backbuffer->Release();
    }
}

LRESULT __stdcall wndproc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    if (msg == WM_KEYDOWN && wparam == VK_INSERT) {
        g_menu_open = !g_menu_open;
    }
    if (g_menu_open && ImGui_ImplWin32_WndProcHandler(hwnd, msg, wparam, lparam))
        return TRUE;
    return CallWindowProcW(o_wndproc, hwnd, msg, wparam, lparam);
}

bool init_imgui(IDXGISwapChain* swap) {
    if (FAILED(swap->GetDevice(__uuidof(ID3D11Device),
                               reinterpret_cast<void**>(&g_device)))) {
        logf("[x] GetDevice failed");
        return false;
    }
    g_device->GetImmediateContext(&g_context);

    DXGI_SWAP_CHAIN_DESC desc{};
    swap->GetDesc(&desc);
    g_hwnd = desc.OutputWindow;
    logf("[.] hwnd=%p", (void*)g_hwnd);

    create_render_target(swap);
    if (!g_rtv) { logf("[x] CreateRenderTargetView failed"); return false; }

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();
    auto& style = ImGui::GetStyle();
    style.WindowRounding = 4.0f;
    style.FrameRounding = 3.0f;

    ImGui_ImplWin32_Init(g_hwnd);
    ImGui_ImplDX11_Init(g_device, g_context);

    o_wndproc = reinterpret_cast<WNDPROC>(
        SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(wndproc)));

    logf("[+] ImGui initialised");
    return true;
}

void draw_frame(IDXGISwapChain* swap) {
    if (!g_running) {
        if (!init_imgui(swap)) return;
        g_running = true;
    }

    // Drop and recreate the render target when the backbuffer is resized
    // (alt-tab, resolution change, borderless toggle) or it goes stale.
    DXGI_SWAP_CHAIN_DESC desc{};
    if (SUCCEEDED(swap->GetDesc(&desc)) && desc.BufferDesc.Width && desc.BufferDesc.Height) {
        static UINT last_w = 0, last_h = 0;
        if (desc.BufferDesc.Width != last_w || desc.BufferDesc.Height != last_h) {
            if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
            last_w = desc.BufferDesc.Width;
            last_h = desc.BufferDesc.Height;
        }
    }
    if (!g_rtv) create_render_target(swap);
    if (!g_rtv) return;

    ImGui_ImplWin32_NewFrame();
    ImGui_ImplDX11_NewFrame();
    ImGui::NewFrame();

    const ImGuiIO& io = ImGui::GetIO();
    esp::render(ImGui::GetBackgroundDrawList(),
                static_cast<int>(io.DisplaySize.x),
                static_cast<int>(io.DisplaySize.y));
    menu::render();

    ImGui::Render();
    g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

HRESULT __stdcall hooked_present(IDXGISwapChain* swap, UINT sync, UINT flags) {
    static bool logged = false;
    if (!logged) { logf("[>] Present() fired"); logged = true; }
    draw_frame(swap);
    return o_present(swap, sync, flags);
}

HRESULT __stdcall hooked_present1(IDXGISwapChain1* swap, UINT sync, UINT flags,
                                  const DXGI_PRESENT_PARAMETERS* params) {
    static bool logged = false;
    if (!logged) { logf("[>] Present1() fired"); logged = true; }
    draw_frame(swap);
    return o_present1(swap, sync, flags, params);
}

void patch_slot(void** vtbl, int index, void* detour, void** original, const char* name) {
    if (!vtbl[index]) { logf("[x] vtable[%d] (%s) null", index, name); return; }
    DWORD old = 0;
    VirtualProtect(&vtbl[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &old);
    *original = vtbl[index];
    vtbl[index] = detour;
    VirtualProtect(&vtbl[index], sizeof(void*), old, &old);
    logf("[+] hooked %s (slot %d)", name, index);
}

} // namespace

namespace hooks {

void install() {
    log_init();
    logf("[*] install() begin");

    WNDCLASSEXW wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcW;
    wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"nyx_dummy";
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, wc.lpszClassName, L"", WS_OVERLAPPEDWINDOW,
                                0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* swap = nullptr;
    ID3D11Device* dev = nullptr;
    ID3D11DeviceContext* ctx = nullptr;

    const HRESULT hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
        D3D11_SDK_VERSION, &sd, &swap, &dev, nullptr, &ctx);

    if (SUCCEEDED(hr) && swap) {
        void** vtbl = *reinterpret_cast<void***>(swap);
        patch_slot(vtbl, 8, reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(&hooked_present)),
                   reinterpret_cast<void**>(&o_present), "Present");
        patch_slot(vtbl, 22, reinterpret_cast<void*>(reinterpret_cast<std::uintptr_t>(&hooked_present1)),
                   reinterpret_cast<void**>(&o_present1), "Present1");
    } else {
        logf("[x] D3D11CreateDeviceAndSwapChain failed hr=0x%lX", (unsigned long)hr);
    }

    if (ctx) ctx->Release();
    if (dev) dev->Release();
    if (swap) swap->Release();
    if (hwnd) DestroyWindow(hwnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);

    logf("[*] install() end");
}

} // namespace hooks
