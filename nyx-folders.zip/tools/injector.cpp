// Injector with a remote stub that reports the REAL load error.
// Exit codes: 0 = success, otherwise the Win32 error from LoadLibraryW.
#include <windows.h>
#include <tlhelp32.h>

#include <cstdio>
#include <cwchar>
#include <cstdlib>
#include <cstdint>
#include <vector>

namespace {

DWORD find_pid(const wchar_t* spec) {
    wchar_t* end = nullptr;
    const unsigned long maybe = std::wcstoul(spec, &end, 10);
    if (end && *end == L'\0' && maybe != 0)
        return static_cast<DWORD>(maybe);

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (_wcsicmp(pe.szExeFile, spec) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

// Builds x64 machine code:
//   LoadLibraryW(path); if (result==0) return GetLastError(); else return 0;
std::vector<std::uint8_t> build_stub(std::uint64_t path,
                                     std::uint64_t load_library,
                                     std::uint64_t get_last_error) {
    std::vector<std::uint8_t> s;
    auto bytes = [&](std::initializer_list<std::uint8_t> b) { s.insert(s.end(), b); };
    auto imm64 = [&](std::uint64_t v) { for (int i = 0; i < 8; ++i) s.push_back(static_cast<std::uint8_t>((v >> (8 * i)) & 0xFF)); };

    bytes({0x48, 0x83, 0xEC, 0x28});        // sub rsp, 0x28
    bytes({0x48, 0xB9}); imm64(path);       // mov rcx, path
    bytes({0x48, 0xB8}); imm64(load_library); // mov rax, LoadLibraryW
    bytes({0xFF, 0xD0});                    // call rax
    bytes({0x48, 0x85, 0xC0});              // test rax, rax
    bytes({0x75, 0x00});                    // jnz ok  (patched below)
    const std::size_t jnz_operand = s.size() - 1;
    bytes({0x48, 0xB8}); imm64(get_last_error); // mov rax, GetLastError
    bytes({0xFF, 0xD0});                    // call rax
    bytes({0x48, 0x83, 0xC4, 0x28});        // add rsp, 0x28
    bytes({0xC3});                          // ret  (eax = error)
    const std::size_t ok = s.size();
    bytes({0x31, 0xC0});                    // xor eax, eax
    bytes({0x48, 0x83, 0xC4, 0x28});        // add rsp, 0x28
    bytes({0xC3});                          // ret

    s[jnz_operand] = static_cast<std::uint8_t>(ok - (jnz_operand + 1));
    return s;
}

const char* hint(DWORD err) {
    switch (err) {
    case 0:    return "OK";
    case 5:    return "ERROR_ACCESS_DENIED (run as admin)";
    case 126:  return "ERROR_MOD_NOT_FOUND (a dependency is missing in target)";
    case 193:  return "ERROR_BAD_EXE_FORMAT (arch mismatch)";
    case 577:  return "ERROR_INVALID_IMAGE_HASH (signature / code-integrity block)";
    case 1114: return "ERROR_DLL_INIT_FAILED (DllMain returned false / threw)";
    case 1157: return "ERROR_DLL_NOT_FOUND";
    default:   return "unknown";
    }
}

} // namespace

int wmain(int argc, wchar_t** argv) {
    if (argc < 3) {
        std::wprintf(L"usage: injector.exe <process.exe|pid> <full_path_to.dll>\n");
        return 1;
    }

    const DWORD pid = find_pid(argv[1]);
    if (!pid) { std::wprintf(L"[!] process not found: %ls\n", argv[1]); return 1; }

    HANDLE proc = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
                              PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ,
                              FALSE, pid);
    if (!proc) { std::wprintf(L"[!] OpenProcess failed (%lu), try admin\n", GetLastError()); return 1; }

    const SIZE_T path_bytes = (std::wcslen(argv[2]) + 1) * sizeof(wchar_t);
    LPVOID remote_path = VirtualAllocEx(proc, nullptr, path_bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote_path) { std::wprintf(L"[!] VirtualAllocEx(path) failed: %lu\n", GetLastError()); CloseHandle(proc); return 1; }
    WriteProcessMemory(proc, remote_path, argv[2], path_bytes, nullptr);

    const auto load_library = reinterpret_cast<std::uint64_t>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryW"));
    const auto get_last_error = reinterpret_cast<std::uint64_t>(GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "GetLastError"));

    auto code = build_stub(reinterpret_cast<std::uint64_t>(remote_path), load_library, get_last_error);
    LPVOID remote_code = VirtualAllocEx(proc, nullptr, code.size(), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remote_code) { std::wprintf(L"[!] VirtualAllocEx(code) failed: %lu\n", GetLastError()); CloseHandle(proc); return 1; }
    WriteProcessMemory(proc, remote_code, code.data(), code.size(), nullptr);

    HANDLE th = CreateRemoteThread(proc, nullptr, 0,
        reinterpret_cast<LPTHREAD_START_ROUTINE>(remote_code), nullptr, 0, nullptr);
    if (!th) { std::wprintf(L"[!] CreateRemoteThread failed: %lu\n", GetLastError()); CloseHandle(proc); return 1; }

    WaitForSingleObject(th, 8000);
    DWORD err = 0;
    GetExitCodeThread(th, &err);

    VirtualFreeEx(proc, remote_code, 0, MEM_RELEASE);
    VirtualFreeEx(proc, remote_path, 0, MEM_RELEASE);
    CloseHandle(th);
    CloseHandle(proc);

    if (err == 0) {
        std::wprintf(L"[+] loaded into pid %lu successfully\n", pid);
        return 0;
    }
    std::wprintf(L"[!] load FAILED in pid %lu: error %lu (0x%lX) - %hs\n", pid, err, err, hint(err));
    return 2;
}
